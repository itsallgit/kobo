<div align="center">

# kobo.koplugin

</div>

A KoReader plugin that extends Kobo device functionality with virtual library management and reading
state synchronization.
