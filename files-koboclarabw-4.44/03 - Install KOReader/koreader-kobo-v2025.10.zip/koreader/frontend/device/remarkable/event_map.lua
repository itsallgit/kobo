return {
    [20001] = "SleepCover",
    [102] = "Home",
    [105] = "LPgBack",
    [106] = "RPgFwd",
    [116] = "Power",
    [143] = "Resume",
}
-- 116 is issued when the device gets to sleep, 143 when it wakes up.
